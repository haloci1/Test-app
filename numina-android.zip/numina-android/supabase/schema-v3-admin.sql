-- NUMINA v3 — paneli admin. Ekzekutoje NJË herë te SQL Editor (pas v2). Mund të ekzekutohet sërish pa dëm.

create table if not exists admins (user_id uuid primary key references auth.users on delete cascade);
alter table admins enable row level security;   -- pa policy: askush s'e lexon direkt

create table if not exists reader_payments (
  id bigint generated always as identity primary key,
  reader_id text references readers on delete cascade,
  month date not null, amount_eur numeric not null, paid_at timestamptz default now(), note text,
  unique (reader_id, month)
);
alter table reader_payments enable row level security;
alter table reports add column if not exists resolved_at timestamptz;

create or replace function is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from admins where user_id = auth.uid()) $$;
create or replace function assert_admin() returns void language plpgsql stable security definer set search_path = public as $$
begin if not is_admin() then raise exception 'Vetëm për administratoren'; end if; end $$;

-- përmbledhja
create or replace function admin_stats() returns json language plpgsql security definer set search_path = public as $$
declare r json; begin perform assert_admin();
  select json_build_object(
    'users', (select count(*) from profiles),
    'users_week', (select count(*) from profiles where created_at > now() - interval '7 days'),
    'premium', (select count(*) from profiles where plan like 'premium%'),
    'readers', (select count(*) from readers),
    'online', (select count(*) from readers where online),
    'calls_today', (select count(*) from calls where started_at::date = current_date and status in ('active','ended')),
    'minutes_month', (select coalesce(sum(minutes),0) from calls where started_at >= date_trunc('month', now())),
    'credits_month', (select coalesce(sum(credits_spent),0) from calls where started_at >= date_trunc('month', now())),
    'pending', (select count(*) from auth.users u where u.raw_user_meta_data->>'wants_reader' = 'true' and not exists (select 1 from readers x where x.user_id = u.id)),
    'reports', (select count(*) from reports where not resolved)) into r;
  return r; end $$;

-- lexueset
create or replace function admin_pending_readers() returns table(user_id uuid, email text, name text, created_at timestamptz)
language plpgsql security definer set search_path = public as $$
begin perform assert_admin(); return query
  select u.id, u.email::text, coalesce(u.raw_user_meta_data->>'name',''), u.created_at from auth.users u
  where u.raw_user_meta_data->>'wants_reader' = 'true' and not exists (select 1 from readers x where x.user_id = u.id)
  order by u.created_at desc; end $$;

create or replace function admin_readers() returns table(id text, name text, spec text, types text[], rate int, stars numeric, online boolean, email text, bio text, payout_method text, payout_details text)
language plpgsql security definer set search_path = public as $$
begin perform assert_admin(); return query
  select r.id, r.name, r.spec, r.types, r.rate, r.stars, r.online, u.email::text, r.bio, p.method, p.details
  from readers r left join auth.users u on u.id = r.user_id left join reader_payouts p on p.reader_id = r.id order by r.name; end $$;

create or replace function admin_save_reader(p_id text, p_user uuid, p_name text, p_spec text, p_types text[], p_rate int, p_bio text, p_payout_method text, p_payout_details text)
returns void language plpgsql security definer set search_path = public as $$
begin perform assert_admin();
  if p_id !~ '^[a-z0-9_-]{2,30}$' then raise exception 'ID: vetëm shkronja të vogla, numra, - ose _'; end if;
  insert into readers(id, user_id, name, spec, types, rate, bio) values (p_id, p_user, p_name, p_spec, p_types, greatest(p_rate,1), p_bio)
  on conflict (id) do update set name = excluded.name, spec = excluded.spec, types = excluded.types, rate = excluded.rate, bio = excluded.bio,
    user_id = coalesce(excluded.user_id, readers.user_id);
  insert into reader_payouts(reader_id, method, details) values (p_id, p_payout_method, p_payout_details)
  on conflict (reader_id) do update set method = excluded.method, details = excluded.details; end $$;

create or replace function admin_remove_reader(p_id text) returns void language plpgsql security definer set search_path = public as $$
begin perform assert_admin(); update readers set online = false, user_id = null where id = p_id;
  delete from readers where id = p_id and not exists (select 1 from calls where reader_id = p_id); end $$;

-- klientët
create or replace function admin_users(p_q text) returns table(id uuid, email text, name text, credits int, plan text, created_at timestamptz, calls bigint)
language plpgsql security definer set search_path = public as $$
begin perform assert_admin(); return query
  select p.id, p.email, p.name, p.credits, p.plan, p.created_at, (select count(*) from calls c where c.user_id = p.id)
  from profiles p where coalesce(p_q,'') = '' or p.email ilike '%'||p_q||'%' or p.name ilike '%'||p_q||'%'
  order by p.created_at desc limit 50; end $$;

create or replace function admin_add_credits(p_user uuid, p_amount int, p_note text) returns int
language plpgsql security definer set search_path = public as $$
declare bal int; begin perform assert_admin();
  insert into credit_ledger(user_id, amount, source) values (p_user, p_amount, 'admin:' || gen_random_uuid() || ':' || coalesce(p_note,''));
  update profiles set credits = greatest(credits + p_amount, 0) where id = p_user returning credits into bal; return bal; end $$;

-- pagesat e lexueseve
create or replace function admin_earnings(p_month date) returns table(reader_id text, name text, calls bigint, minutes bigint, credits bigint, payout_eur numeric, paid_eur numeric, paid_at timestamptz, payout_method text, payout_details text)
language plpgsql security definer set search_path = public as $$
begin perform assert_admin(); return query
  select r.id, r.name, count(c.id), coalesce(sum(c.minutes),0)::bigint, coalesce(sum(c.credits_spent),0)::bigint,
    round(coalesce(sum(c.credits_spent),0) * 0.80 * 0.70, 2), pm.amount_eur, pm.paid_at, po.method, po.details
  from readers r
  left join calls c on c.reader_id = r.id and date_trunc('month', c.started_at) = date_trunc('month', p_month::timestamptz) and c.credits_spent > 0
  left join reader_payments pm on pm.reader_id = r.id and pm.month = date_trunc('month', p_month::timestamptz)::date
  left join reader_payouts po on po.reader_id = r.id
  group by r.id, r.name, pm.amount_eur, pm.paid_at, po.method, po.details order by r.name; end $$;

create or replace function admin_mark_paid(p_reader text, p_month date, p_amount numeric) returns void
language plpgsql security definer set search_path = public as $$
begin perform assert_admin();
  insert into reader_payments(reader_id, month, amount_eur) values (p_reader, date_trunc('month', p_month::timestamptz)::date, p_amount)
  on conflict (reader_id, month) do update set amount_eur = excluded.amount_eur, paid_at = now(); end $$;

-- raportet
create or replace function admin_reports() returns table(id bigint, created_at timestamptz, reporter_email text, reader_id text, reason text, resolved boolean)
language plpgsql security definer set search_path = public as $$
begin perform assert_admin(); return query
  select x.id, x.created_at, p.email, x.reader_id, x.reason, x.resolved from reports x left join profiles p on p.id = x.reporter
  order by x.resolved, x.created_at desc limit 100; end $$;
create or replace function admin_resolve_report(p_id bigint) returns void language plpgsql security definer set search_path = public as $$
begin perform assert_admin(); update reports set resolved = true, resolved_at = now() where id = p_id; end $$;

-- të drejtat
revoke execute on function is_admin, assert_admin, admin_stats, admin_pending_readers, admin_readers, admin_save_reader, admin_remove_reader,
  admin_users, admin_add_credits, admin_earnings, admin_mark_paid, admin_reports, admin_resolve_report from public, anon;
grant execute on function is_admin, admin_stats, admin_pending_readers, admin_readers, admin_save_reader, admin_remove_reader,
  admin_users, admin_add_credits, admin_earnings, admin_mark_paid, admin_reports, admin_resolve_report to authenticated;

-- TI je administratorja (ndrysho email-in nëse përdor një tjetër për panelin)
insert into admins(user_id) select id from auth.users where email = 'halocikristi93@gmail.com' on conflict do nothing;
-- llogaria jote ekzistuese e lexueses shënohet si "kërkoi të jetë lexuese"
update auth.users set raw_user_meta_data = coalesce(raw_user_meta_data,'{}'::jsonb) || '{"wants_reader":"true"}'
 where id in (select user_id from readers where user_id is not null);
