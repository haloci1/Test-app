-- NUMINA — databaza (Supabase → SQL Editor → ekzekuto këtë skedar)

create table if not exists profiles (
  id uuid primary key references auth.users on delete cascade,
  name text, birth_date date, birth_time time, birth_place text,
  plan text not null default 'free',
  credits int not null default 3,
  created_at timestamptz default now()
);

create table if not exists readers (
  id text primary key,
  name text not null, spec text, types text[] default '{}',
  rate int not null default 2,            -- kredite / minutë
  online boolean default false
);

-- Të dhënat e pagesës së lexueseve: pa policy = vetëm admin/serveri i sheh
create table if not exists reader_payouts (
  reader_id text primary key references readers on delete cascade,
  method text,                            -- 'iban' ose 'paypal'
  details text                            -- IBAN ose email PayPal
);

create table if not exists calls (
  id bigint generated always as identity primary key,
  user_id uuid references profiles on delete set null,
  reader_id text references readers,
  channel text not null, mode text, reading_type text,
  started_at timestamptz default now(), ended_at timestamptz,
  minutes int default 0, credits_spent int default 0
);

create table if not exists credit_ledger (
  id bigint generated always as identity primary key,
  user_id uuid references profiles on delete cascade,
  amount int not null, source text unique,  -- unique: e njëjta pagesë s'shtohet dy herë
  created_at timestamptz default now()
);

create table if not exists reports (
  id bigint generated always as identity primary key,
  reporter uuid references profiles on delete set null,
  reader_id text, call_id bigint, reason text,
  created_at timestamptz default now(), resolved boolean default false
);

-- Shto kredite në mënyrë të sigurt (thirret vetëm nga funksionet e serverit)
create or replace function add_credits(p_user uuid, p_amount int, p_source text)
returns void language plpgsql security definer as $$
begin
  insert into credit_ledger(user_id, amount, source) values (p_user, p_amount, p_source);
  update profiles set credits = credits + p_amount where id = p_user;
exception when unique_violation then
  null; -- pagesa ishte regjistruar tashmë
end $$;
revoke execute on function add_credits from public, anon, authenticated;

-- Fitimet e lexueseve për muajin (për pagesat manuale me IBAN/PayPal)
create or replace view reader_earnings with (security_invoker = true) as
select r.id, r.name, date_trunc('month', c.started_at) as month,
       sum(c.credits_spent) as credits,
       round(sum(c.credits_spent) * 0.80 * 0.70, 2) as payout_eur  -- ≈0.80 € neto për kredit (pas Google) × 70% për lexuesen
from calls c join readers r on r.id = c.reader_id
group by 1,2,3;

-- Siguria: secili sheh vetëm të dhënat e veta
alter table profiles enable row level security;
alter table calls enable row level security;
alter table credit_ledger enable row level security;
alter table reports enable row level security;
alter table readers enable row level security;
alter table reader_payouts enable row level security;
create policy "profili im" on profiles for select using (auth.uid() = id);
create policy "ndrysho profilin" on profiles for update using (auth.uid() = id);
create policy "thirrjet e mia" on calls for select using (auth.uid() = user_id);
create policy "kreditet e mia" on credit_ledger for select using (auth.uid() = user_id);
create policy "raporto" on reports for insert with check (auth.uid() = reporter);
create policy "lexueset publike" on readers for select using (true);
