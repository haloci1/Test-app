// Kap (capture) një porosi PayPal nga serveri dhe shton kreditet. Vetëm për versionin WEB.
// (Në Android pagesat bëhen me Google Play Billing — kjo është e detyrueshme nga Google.)
//   supabase secrets set PAYPAL_CLIENT_ID=... PAYPAL_SECRET=... PAYPAL_ENV=live
//   supabase functions deploy paypal-capture
import { createClient } from "npm:@supabase/supabase-js@2";

const PRICES: Record<string, { amount: string; credits: number }> = {
  credits_10: { amount: "9.99", credits: 10 },
  credits_30: { amount: "24.99", credits: 30 },
};
const base = () => Deno.env.get("PAYPAL_ENV") === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";

async function accessToken() {
  const auth = btoa(`${Deno.env.get("PAYPAL_CLIENT_ID")}:${Deno.env.get("PAYPAL_SECRET")}`);
  const r = await fetch(`${base()}/v1/oauth2/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
  });
  return (await r.json()).access_token as string;
}

Deno.serve(async (req) => {
  const { orderId, productId } = await req.json();
  const product = PRICES[productId];
  if (!product) return new Response("produkt i panjohur", { status: 400 });

  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const jwt = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
  const { data: { user } } = await sb.auth.getUser(jwt);
  if (!user) return new Response("jo i identifikuar", { status: 401 });

  const r = await fetch(`${base()}/v2/checkout/orders/${orderId}/capture`, {
    method: "POST",
    headers: { Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" },
  });
  const order = await r.json();
  const cap = order?.purchase_units?.[0]?.payments?.captures?.[0];
  if (order.status !== "COMPLETED" || cap?.amount?.value !== product.amount) {
    return new Response(JSON.stringify({ ok: false, order }), { status: 400 });
  }
  await sb.rpc("add_credits", { p_user: user.id, p_amount: product.credits, p_source: `paypal:${orderId}` });
  return new Response(JSON.stringify({ ok: true, credits: product.credits }), { headers: { "Content-Type": "application/json" } });
});
