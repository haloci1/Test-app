// Jep token Agora VETËM për përdoruesit e futur në llogari dhe VETËM për thirrjet e tyre.
//  - klienti merr token vetëm për kanalin e thirrjes që nisi vetë
//  - lexuesja merr token vetëm për thirrjet që i drejtohen asaj
// Secrets: AGORA_APP_ID, AGORA_APP_CERTIFICATE (SUPABASE_URL dhe SUPABASE_ANON_KEY i jep Supabase vetë).
// "Verify JWT" mbetet OFF: kontrollin e bëjmë këtu brenda.
import { RtcTokenBuilder, RtcRole } from "npm:agora-token@2.0.7";
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const url = new URL(req.url);
  const channel = url.searchParams.get("channel") ?? "";
  if (!/^numina_[A-Z0-9]{6}$/.test(channel)) return json({ error: "kanal i pavlefshëm" }, 400);

  const auth = req.headers.get("Authorization") ?? "";
  if (!auth.startsWith("Bearer ")) return json({ error: "duhet të hysh në llogari" }, 401);

  // klient Supabase me identitetin e përdoruesit: rregullat e databazës (RLS) vlejnë
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: auth } },
  });
  const { data: { user } } = await sb.auth.getUser(auth.slice(7));
  if (!user) return json({ error: "sesioni ka skaduar, hyr përsëri" }, 401);

  // RLS lejon vetëm klientin e thirrjes ose lexuesen e saj ta shohin këtë rresht
  const { data: rows } = await sb.from("calls").select("id")
    .eq("channel", channel).in("status", ["ringing", "active"]).limit(1);
  if (!rows || rows.length === 0) return json({ error: "nuk ke qasje në këtë thirrje" }, 403);

  const ttl = 60 * 60; // 1 orë
  const token = RtcTokenBuilder.buildTokenWithUid(
    Deno.env.get("AGORA_APP_ID")!, Deno.env.get("AGORA_APP_CERTIFICATE")!, channel, 0, RtcRole.PUBLISHER, ttl, ttl);
  return json({ token });
});
