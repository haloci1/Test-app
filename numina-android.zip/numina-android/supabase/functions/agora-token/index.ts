// Jep token Agora për një kanal thirrjeje. Deploy:
//   supabase secrets set AGORA_APP_ID=... AGORA_APP_CERTIFICATE=...
//   supabase functions deploy agora-token --no-verify-jwt
// Pastaj vendos URL-në te www/config.js → AGORA_TOKEN_URL.
// Faza 2: kërko login (hiq --no-verify-jwt) dhe kontrollo që përdoruesi ka kredite.
import { RtcTokenBuilder, RtcRole } from "npm:agora-token@2.0.7";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type",
};

Deno.serve((req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const url = new URL(req.url);
  const channel = url.searchParams.get("channel") ?? "";
  const uid = Number(url.searchParams.get("uid") ?? "0");
  if (!/^numina_[A-Z0-9]{6}$/.test(channel)) {
    return new Response(JSON.stringify({ error: "kanal i pavlefshëm" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
  }
  const appId = Deno.env.get("AGORA_APP_ID")!;
  const cert = Deno.env.get("AGORA_APP_CERTIFICATE")!;
  const ttl = 60 * 60; // 1 orë
  const token = RtcTokenBuilder.buildTokenWithUid(appId, cert, channel, uid, RtcRole.PUBLISHER, ttl, ttl);
  return new Response(JSON.stringify({ token }), { headers: { ...cors, "Content-Type": "application/json" } });
});
