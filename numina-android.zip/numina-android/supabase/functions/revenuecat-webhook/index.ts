// RevenueCat → njofton serverin kur dikush blen në Google Play.
// Shton kreditet për blerjet "credits_10"/"credits_30" dhe ruan planin Premium.
//   supabase secrets set REVENUECAT_WEBHOOK_AUTH=një-fjalëkalim-i-gjatë
//   supabase functions deploy revenuecat-webhook --no-verify-jwt
// Në RevenueCat → Integrations → Webhooks: URL e funksionit + Authorization header = i njëjti fjalëkalim.
import { createClient } from "npm:@supabase/supabase-js@2";

const CREDITS: Record<string, number> = { credits_10: 10, credits_30: 30, premium_yearly: 20 };

Deno.serve(async (req) => {
  if (req.headers.get("Authorization") !== Deno.env.get("REVENUECAT_WEBHOOK_AUTH")) {
    return new Response("unauthorized", { status: 401 });
  }
  const { event } = await req.json();
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const userId = event.app_user_id as string;
  const product = String(event.product_id ?? "").split(":")[0];

  if (["NON_RENEWING_PURCHASE", "INITIAL_PURCHASE"].includes(event.type) && CREDITS[product]) {
    await sb.rpc("add_credits", { p_user: userId, p_amount: CREDITS[product], p_source: `play:${event.transaction_id}` });
  }
  if (["INITIAL_PURCHASE", "RENEWAL", "UNCANCELLATION", "PRODUCT_CHANGE"].includes(event.type) && product.startsWith("premium")) {
    await sb.from("profiles").update({ plan: product }).eq("id", userId);
  }
  if (event.type === "EXPIRATION") {
    await sb.from("profiles").update({ plan: "free" }).eq("id", userId);
  }
  return new Response("ok");
});
