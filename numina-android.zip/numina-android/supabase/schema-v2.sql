-- NUMINA v2 — llogaritë, lexueset dhe thirrjet live.
-- Ekzekutoje NJË herë te SQL Editor, PAS schema.sql. Mund të ekzekutohet sërish pa dëm.

-- ---------- profilet ----------
alter table profiles add column if not exists email text;
alter table profiles add column if not exists gender text;

-- profili krijohet vetë kur dikush hap llogari
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, email, name, birth_date, birth_time, birth_place)
  values (new.id, new.email,
          new.raw_user_meta_data->>'name',
          nullif(new.raw_user_meta_data->>'birth_date','')::date,
          nullif(new.raw_user_meta_data->>'birth_time','')::time,
          new.raw_user_meta_data->>'birth_place')
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- përdoruesi ndryshon vetëm të dhënat personale, JO kreditet ose planin
revoke update on profiles from authenticated, anon;
grant update (name, birth_date, birth_time, birth_place, gender) on profiles to authenticated;

-- ---------- lexueset ----------
alter table readers add column if not exists user_id uuid unique references auth.users on delete set null;
alter table readers add column if not exists bio text;
alter table readers add column if not exists stars numeric default 5.0;

-- ---------- thirrjet ----------
alter table calls add column if not exists status text not null default 'ringing'; -- ringing | active | ended | declined | missed
alter table calls add column if not exists rate int not null default 2;
alter table calls add column if not exists answered_at timestamptz;
create index if not exists calls_reader_status on calls(reader_id, status);

drop policy if exists "thirrjet e mia" on calls;
drop policy if exists "thirrjet: klienti ose lexuesja" on calls;
create policy "thirrjet: klienti ose lexuesja" on calls for select using (
  auth.uid() = user_id or reader_id in (select id from readers where user_id = auth.uid()));

-- Realtime: lexuesja merr thirrjen në çast, klienti sheh kur pranohet
do $$ begin
  begin alter publication supabase_realtime add table calls; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table readers; exception when duplicate_object then null; end;
end $$;

-- ---------- funksionet (të sigurta, ekzekutohen në server) ----------
create or replace function my_reader_id() returns text language sql stable security definer set search_path = public as $$
  select id from readers where user_id = auth.uid() $$;

-- klienti nis thirrjen
create or replace function start_call(p_reader text, p_mode text, p_type text)
returns table(call_id bigint, channel text) language plpgsql security definer set search_path = public as $$
declare r readers; c int; ch text;
begin
  if auth.uid() is null then raise exception 'Duhet të hysh në llogari'; end if;
  select * into r from readers where id = p_reader;
  if r is null or not r.online then raise exception 'Lexuesja nuk është online'; end if;
  select credits into c from profiles where id = auth.uid();
  if coalesce(c,0) < r.rate then raise exception 'Nuk ke kredite të mjaftueshme'; end if;
  update calls set status = 'missed', ended_at = now() where user_id = auth.uid() and status = 'ringing';
  ch := 'numina_' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6));
  insert into calls(user_id, reader_id, channel, mode, reading_type, rate, status)
    values (auth.uid(), p_reader, ch, p_mode, p_type, r.rate, 'ringing') returning id into call_id;
  channel := ch; return next;
end $$;

-- llogarit dhe zbret kreditet sipas minutave reale (nga momenti që lexuesja pranon)
create or replace function tick_call(p_call bigint) returns int
language plpgsql security definer set search_path = public as $$
declare k calls; due int; owe int; bal int;
begin
  select * into k from calls where id = p_call for update;
  if k is null or k.user_id <> auth.uid() then raise exception 'Thirrje e panjohur'; end if;
  if k.status <> 'active' or k.answered_at is null then
    select credits into bal from profiles where id = k.user_id; return bal; end if;
  due := greatest(1, ceil(extract(epoch from now() - k.answered_at) / 60.0)::int);
  owe := due * k.rate - k.credits_spent;
  select credits into bal from profiles where id = k.user_id for update;
  if owe > 0 then
    if bal < owe then
      update calls set status = 'ended', ended_at = now(), minutes = due - 1,
        credits_spent = credits_spent + bal where id = p_call;
      update profiles set credits = 0 where id = k.user_id;
      return -1;
    end if;
    update profiles set credits = credits - owe where id = k.user_id returning credits into bal;
    update calls set credits_spent = credits_spent + owe, minutes = due where id = p_call;
  end if;
  return bal;
end $$;

-- lexuesja pranon / refuzon
create or replace function answer_call(p_call bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  update calls set status = 'active', answered_at = now()
   where id = p_call and status = 'ringing' and reader_id = my_reader_id();
  if not found then raise exception 'Thirrja nuk është më aktive'; end if;
end $$;
create or replace function decline_call(p_call bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  update calls set status = 'declined', ended_at = now()
   where id = p_call and status = 'ringing' and reader_id = my_reader_id();
end $$;

-- secili mund ta mbyllë thirrjen (klienti paguan minutën e fundit me tick_call para kësaj)
create or replace function end_call(p_call bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  update calls set status = case when status = 'ringing' then 'missed' else 'ended' end, ended_at = now()
   where id = p_call and status in ('ringing','active')
     and (user_id = auth.uid() or reader_id = my_reader_id());
end $$;

-- lexuesja ndez / fik online
create or replace function set_online(p_online boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  update readers set online = p_online where user_id = auth.uid();
  if not found then raise exception 'Kjo llogari nuk është lexuese'; end if;
end $$;

-- fshirja e llogarisë nga app-i (kërkesë e Google Play)
create or replace function delete_me() returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from auth.users where id = auth.uid();
end $$;

-- add_credits thirret VETËM nga serveri (webhook-et). Postgres e lejon për 'public' si parazgjedhje: e mbyllim.
revoke execute on function add_credits(uuid,int,text) from public, anon, authenticated;
revoke execute on function start_call, tick_call, answer_call, decline_call, end_call, set_online, delete_me, my_reader_id from public;
revoke execute on function start_call, tick_call, answer_call, decline_call, end_call, set_online, delete_me, my_reader_id from anon;
grant execute on function start_call, tick_call, answer_call, decline_call, end_call, set_online, delete_me, my_reader_id to authenticated;

-- ---------- ndihmës për ty (admin) ----------
-- Si ta bësh dikë LEXUESE (pasi ajo të ketë hapur llogari te reader.html):
--   insert into readers(id, name, spec, types, rate, user_id)
--   select 'mira', 'Mira', 'Lexim filxhani kafeje', '{Filxhan}', 2, id from auth.users where email = 'mira@email.com';
--
-- Si t'i shtosh kredite dikujt për provë:
--   update profiles set credits = credits + 20 where email = 'emaili@yt.com';
