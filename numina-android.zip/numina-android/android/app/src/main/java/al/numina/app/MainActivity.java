package al.numina.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
