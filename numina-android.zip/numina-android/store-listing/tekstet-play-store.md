# Tekstet për Play Console → Store listing

## Emri i app-it (max 30 shenja)
NUMINA: Tarot, Filxhan, Yje

## Përshkrimi i shkurtër (max 80 shenja)
Tarot, kristale, horoskop dhe lexim filxhani ose dore me video call live.

## Përshkrimi i plotë
NUMINA është hapësira jote për qetësi, qartësi dhe përgjigje.

✦ Lexim Tarot: zgjidh temën (dashuri, familje, karrierë), përziej letrat dhe merr përgjigjen. Tarot, Oracle dhe Lenormand.
✦ Filxhan dhe dorë live: bëj video call ose telefonatë me lexuese të verifikuara. Kamera e pasme në Full HD tregon qartë filxhanin e kafesë ose vijat e dorës.
✦ Profili yt astrologjik: shenja, numri Life Path, numrat e fatit, guri i lindjes, kristali, pikat e forta dhe të dobëta.
✦ Kristale dhe energji: kuptimi i çdo kristali dhe si ta përdorësh.
✦ Rituale dhe pastrim: Hëna e Re, Hëna e Plotë, pastrimi i hapësirës, me fazën e Hënës çdo ditë.
✦ Vendet e shenjta: Shqipëria dhe bota, me hartë.
✦ Merr frymë: meditim i udhëhequr 3-minutësh.
✦ Çdo mëngjes: afirmimi, ushtrimi i manifestimit dhe meditimi i ditës.

Premium: letra pa limit, të gjitha funksionet, pa reklama. 5 ditë falas.

Leximet janë për argëtim dhe vetë-reflektim. Nuk zëvendësojnë këshilla profesionale.

## Kategoria
Lifestyle (ose Entertainment)

## Email kontakti
support@numina.app  ← vendos email-in tënd real

## Grafikat (në këtë dosje)
- icon-512.png → App icon
- feature-graphic-1024x500.png → Feature graphic
- screenshot-*.png → Phone screenshots (1080×1920). Rekomandohet t'i bësh sërish nga telefoni.

## Data safety (përgjigjet)
- Mbledh të dhëna: PO. Kriptim gjatë transmetimit: PO. Përdoruesi mund të kërkojë fshirjen: PO (URL: legal/delete-account.html).
- Personal info: Emri, Email → Account management, App functionality.
- Personal info → Other (data/ora/vendi i lindjes) → App functionality.
- Photos and videos, Audio (gjatë thirrjeve, nuk ruhen) → App functionality.
- Financial info → Purchase history → App functionality.
- Device or other IDs (AdMob) → Advertising. Shared with: Google AdMob.
- App activity → App interactions → Analytics (vetëm nëse shton analitikë).

## Content rating
Plotëso pyetësorin me sinqeritet. Përmend: komunikim mes përdoruesve (video/zë me lexueset) = PO.

## Target audience
18+ vetëm.

## Ads
"Contains ads" = PO.

## App access
Jep një llogari demo për rishikuesit e Google (email + fjalëkalim) dhe shkruaj: "Video call: përdor kodin që shfaqet; lexuesja testuese është online 10:00–18:00".
