/* =====================================================================
   NUMINA — ÇELËSAT. Plotësoji këtu (jo në index.html).
   Fushë bosh = ajo pjesë punon në modalitetin DEMO.
   MOS vendos këtu sekrete (App Certificate, PayPal Secret, Service Role Key):
   ato shkojnë vetëm te backend-i (supabase/functions, si "secrets").
   ===================================================================== */
window.NUMINA_CONFIG = {
  // Video call + telefonatë — console.agora.io → Projects → App ID
  AGORA_APP_ID: '2c871d838d77451b89d2118796fe1d36',
  // URL e funksionit që jep token Agora (pas "supabase functions deploy agora-token")
  // p.sh. 'https://XXXX.supabase.co/functions/v1/agora-token'
  AGORA_TOKEN_URL: 'https://wsjxtchqmdaxpawioorj.supabase.co/functions/v1/agora-token',
  SUPABASE_URL: 'https://wsjxtchqmdaxpawioorj.supabase.co',
  SUPABASE_KEY: 'sb_publishable_CnIT_nTxJhP5jGpNNyK0aQ_avllXxoS',

  // Pagesat në Android (Google Play Billing: kartë, PayPal, Google Pay) — app.revenuecat.com → API keys → Google Play (goog_...)
  REVENUECAT_ANDROID_KEY: '',

  // Pagesat në versionin web — developer.paypal.com → Apps & Credentials → Client ID (Live)
  PAYPAL_CLIENT_ID: '',

  // AdMob — admob.google.com → Apps → Ad units → Banner. Ky është ID TEST i Google.
  ADMOB_BANNER_ID: 'ca-app-pub-3940256099942544/9214589741',

  // Faqet ligjore (hostoji në Cloudflare Pages / GitHub Pages — shih README)
  PRIVACY_URL: 'https://haloci1.github.io/Test-app/legal/privacy.html',
  TERMS_URL: 'https://haloci1.github.io/Test-app/legal/terms.html',
  DELETE_URL: 'https://haloci1.github.io/Test-app/legal/delete-account.html',

  COMMISSION: 0.30
};
