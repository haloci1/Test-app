# NUMINA: projekti Android për Play Store

Ky projekt e mbështjell app-in HTML në një app Android me **Capacitor 8**. Kodi i app-it është në `www/`. Dosja `android/` është projekti që hapet në Android Studio për të ndërtuar skedarin `.aab` që dorëzohet te Google.

```
numina-android/
├─ www/                 ← app-i (index.html), faqja e lexueseve (reader.html), fontet, Agora SDK, faqet ligjore
│  └─ config.js         ← KËTU vendos çelësat (Agora, RevenueCat, AdMob, PayPal)
├─ android/             ← projekti Android (targetSdk 36, siç kërkon Google nga 31 gusht 2026)
├─ assets/              ← ikona dhe splash (burimi); "npm run icons" i rigjeneron
├─ store-listing/       ← ikona 512, feature graphic, screenshots, tekstet dhe përgjigjet për Play Console
├─ supabase/            ← backend-i: databaza + 3 funksione (token Agora, PayPal, RevenueCat)
└─ package.json
```

---

## 0. Provoje në telefon pa instaluar asgjë (GitHub ndërton APK-në)

1. github.com → **New repository** → emri `numina` → **Private** → Create.
2. Në faqen e repo-s: **uploading an existing file** → tërhiq të gjitha skedarët e kësaj dosjeje (përveç `node_modules`) → **Commit changes**. Kontrollo që është ngarkuar edhe dosja `.github` (ka një pikë përpara emrit, prandaj shpesh fshihet: në Mac shtyp Cmd+Shift+. për ta parë).
3. Hap skedën **Actions**. Ndërtimi “Ndërto APK” fillon vetë dhe zgjat rreth 5–8 minuta. Nëse nuk nis, shtyp **Run workflow**.
4. Kur del ✓ jeshile: hap run-in → poshtë te **Artifacts** → shkarko `numina-apk` (zip) → brenda është `app-debug.apk`.
5. Dërgoje APK-në në telefonin Android (email, Drive ose WhatsApp për veten) → hape → lejo **“Instalo aplikacione të panjohura”** kur ta kërkojë → Instalo.

Çdo ndryshim që ngarkon në GitHub ndërton automatikisht një APK të re. Kjo APK është vetëm për provë dhe nuk dorëzohet në Play Store, sepse për Play Store duhet `.aab` e nënshkruar (hapi 7). Llogaria falas e GitHub ka 2,000 minuta ndërtimi në muaj për repo private, që mjaftojnë për rreth 200 ndërtime.

---

## 1. Instalo programet (një herë)

1. **Node.js 22 LTS**: nodejs.org
2. **Android Studio** (versioni më i ri): developer.android.com/studio. Gjatë instalimit pranon Android SDK. Android Studio sjell edhe Java-n.
3. **VS Code** me shtesën *Ionic* (VS Code ta sugjeron vetë kur hap dosjen).

## 2. Hape në VS Code

```bash
cd numina-android
npm install
npx cap sync android      # kopjon www/ te android/ dhe lidh shtesat
npx cap open android      # hap Android Studio
```

Sa herë që ndryshon diçka te `www/`, ekzekuto sërish `npx cap sync android`.

Për ta parë app-in në shfletues gjatë punës: `npm run serve`, pastaj hap http://localhost:8080.

## 3. Provoje në telefon

1. Në telefon: *Cilësimet → Rreth telefonit →* shtyp 7 herë *Build number* → *Developer options → USB debugging* ON.
2. Lidhe me kabllo dhe në Android Studio shtyp ▶ **Run**.

Pa çelësa, app-i punon në **modalitetin demo**: pagesat simulohen, video call-i tregon kamerën tënde dhe kodin e thirrjes.

## 4. Vendos çelësat te `www/config.js`

| Çelësi | Ku e merr | Çfarë ndez |
|---|---|---|
| `AGORA_APP_ID` | console.agora.io → New project → *Secured mode (token)* | Video call dhe telefonatë reale |
| `AGORA_TOKEN_URL` | pas hapit 6 (Supabase) | Siguria e thirrjeve |
| `REVENUECAT_ANDROID_KEY` | app.revenuecat.com → Project → Google Play app → API key (`goog_…`) | Pagesat në Android |
| `ADMOB_BANNER_ID` | admob.google.com → Apps → Add app → Ad unit *Banner* | Reklamat reale |
| `PAYPAL_CLIENT_ID` | developer.paypal.com (vetëm për versionin web) | PayPal në web |

**Edhe një vend për AdMob:** te `android/app/src/main/AndroidManifest.xml` zëvendëso `ca-app-pub-3940256099942544~3347511713` me **App ID**-në tënde. Ky ID ka shenjën `~`, jo `/`.

> Mos i fut kurrë në `config.js` sekretet: *App Certificate* i Agora, *Secret* i PayPal, *service_role* i Supabase. Ato shkojnë vetëm te Supabase si `secrets`.

## 5. Pagesat: si funksionojnë

- **Në app-in nga Play Store** Google e kërkon detyrimisht **Google Play Billing** për abonimet dhe kreditet. Kjo është e mirë për ty: klienti paguan me **kartë, PayPal ose Google Pay** brenda Google Play, dhe Google të paguan në bankë. Shqipëria është vend i mbështetur për llogari tregtari në Google Play (paguan në USD), pa nevojë për Stripe.
- **RevenueCat** e lidh Google Play Billing me app-in. Është falas deri në 2,500 $ të ardhura në muaj, pastaj merr 1%.
- **Në versionin web** përdoret PayPal (butoni PayPal dhe “Debit or Credit Card”). Para se ta nisësh, konfirmo që llogaria jote PayPal Business në Shqipëri mund të **marrë** pagesa dhe t'i tërheqë në bankë.

**Krijo produktet në Play Console → Monetize** (ID-të duhet të jenë saktësisht këto):

| ID | Lloji | Çmimi |
|---|---|---|
| `premium_monthly` | Subscription, base plan mujor, free trial 5 ditë | 7.99 € |
| `premium_yearly` | Subscription, base plan vjetor, free trial 5 ditë | 49.99 € |
| `credits_10` | In-app product (consumable) | 9.99 € |
| `credits_30` | In-app product (consumable) | 24.99 € |

Në RevenueCat krijo *Entitlement* me emrin `premium` dhe lidh të dy abonimet me të.

**Pagesa e lexueseve:** ato i paguan ti një herë në muaj me transfertë bankare ose PayPal. Shuma llogaritet te `reader_earnings` në Supabase (70% për lexuesen, 30% për app-in, pas tarifës së Google).

## 6. Backend-i (Supabase)

1. Krijo projekt falas në supabase.com.
2. *SQL Editor* → ngjit `supabase/schema.sql` → *Run*.
3. Instalo CLI-në (`npm i -g supabase`), pastaj:
```bash
supabase login
supabase link --project-ref XXXX
supabase secrets set AGORA_APP_ID=... AGORA_APP_CERTIFICATE=...
supabase secrets set REVENUECAT_WEBHOOK_AUTH=një-fjalëkalim-i-gjatë
supabase functions deploy agora-token --no-verify-jwt
supabase functions deploy revenuecat-webhook --no-verify-jwt
supabase functions deploy paypal-capture        # vetëm për web
```
4. Vendos `https://XXXX.supabase.co/functions/v1/agora-token` te `AGORA_TOKEN_URL`.

> **Çfarë mbetet për fazën 2:** Tani për tani profili, kreditet dhe koleksioni ruhen në telefon. Para se të hapësh lexime me para reale, duhen lidhur me Supabase: login, kreditet në server, lista e lexueseve online, dhe njoftimi i lexueses kur e thërret dikush (tani lexuesja hyn me kodin 6-shifror te `reader.html`). Tabelat dhe funksionet për këtë janë gati.

## 7. Ndërto skedarin për Play Store (.aab)

1. Ndrysho `versionCode` (1, 2, 3…) dhe `versionName` te `android/app/build.gradle` për çdo version të ri.
2. Android Studio → **Build → Generate Signed App Bundle / APK → Android App Bundle**.
3. *Create new keystore*. **Ruaje skedarin `.jks` dhe fjalëkalimin në 2 vende të sigurta.** Pa to nuk mund ta përditësosh më app-in.
4. Zgjidh *release* → *Create*. Skedari del te `android/app/release/app-release.aab`.

> **Emri i paketës `al.numina.app`** nuk ndryshohet dot pas ngarkimit të parë. Nëse do një tjetër, ndryshoje te `capacitor.config.json`, `android/app/build.gradle` dhe `strings.xml` para se të ngarkosh.

## 8. Play Console: dorëzimi

1. play.google.com/console → krijo llogari **Personal** (25 $ një herë) dhe verifiko identitetin.
2. **Create app** → NUMINA, App, Free (me blerje brenda).
3. Plotëso **Store listing** me tekstet dhe grafikat nga `store-listing/`.
4. **App content:** Privacy policy URL, Data safety, Content rating, Target audience 18+, Ads = Yes, App access (llogari demo). Përgjigjet janë te `store-listing/tekstet-play-store.md`.
5. **Testing → Closed testing:** ngarko `.aab`, shto **të paktën 12 testues** (email Gmail) dhe mbaji të regjistruar **14 ditë rresht**. Kjo vlen për llogaritë personale të reja.
6. Pas 14 ditëve: **Dashboard → Apply for production**. Rishikimi zakonisht zgjat disa ditë.

## 9. Hostimi i faqeve (privacy, reader.html, versioni web)

Kodi qëndron **privat** në GitHub. Faqet hostohen falas me **Cloudflare Pages**:

1. github.com → *New repository* → **Private** → ngarko këtë dosje (pa `node_modules`).
2. dash.cloudflare.com → *Workers & Pages → Create → Pages → Connect to Git* → zgjidh repo-n privat.
3. *Build command*: bosh · *Output directory*: `www` → Deploy.
4. Merr adresën `https://numina-app.pages.dev` (ose lidh domenin tënd) dhe vendose te `config.js` → `PRIVACY_URL`, `TERMS_URL`, `DELETE_URL`.

GitHub Pages nga repo privat kërkon GitHub Pro (4 $/muaj). Cloudflare Pages e bën falas.

## 10. Lista para publikimit

- [ ] Çelësat realë te `config.js` + App ID i AdMob te `AndroidManifest.xml`
- [ ] Produktet në Play Console + RevenueCat
- [ ] Faqet ligjore online, me email-in tënd real dhe të kontrolluara nga një jurist
- [ ] Testuar në 2–3 telefona: video call me kamerën e pasme, drita, pagesa testuese (*License testing*)
- [ ] 12 testues × 14 ditë
- [ ] Keystore-i i ruajtur në dy vende
